# Gram Saathi — organised project

## Folder structure

- `index.html` — main website markup
- `css/style.css` — website styles (moved from the supplied CSS file)
- `js/app.js` — application JavaScript (extracted from the supplied HTML)
- `assets/images/village.jpg` — supplied image asset

## Run / deploy

This is a static website. Keep `index.html` at the project root.
Deploy the project root with Vercel, or serve it using any static web server.

The Supabase JavaScript SDK and Google Fonts are still loaded from their existing CDN URLs.
The Supabase project configuration and application logic have been preserved.

## Important

- Do not publish Supabase service-role keys, SMTP passwords, or other private credentials.
- The browser-side Supabase anon/publishable key is expected to be public; secure access with Supabase Row Level Security.
- After uploading these files to GitHub, wait for a successful Vercel Production deployment and test login, navigation, images, and admin/resident workflows.
