/* =========================================
           9.1 SUPABASE CONFIGURATION
        ========================================== */

        // Publishable key is intended for browser use.
        // Ensure Supabase Row Level Security (RLS) is configured.

        const SUPABASE_URL = 'https://vwgzxzakgqfiyrwoptoz.supabase.co';

        const SUPABASE_ANON_KEY = 'sb_publishable_T_tCK6r1_77VXKs3bkj87g_KfqhmpM_';

        const db = supabase.createClient(
            SUPABASE_URL,
            SUPABASE_ANON_KEY
        );


        /* =========================================
           9.2 GLOBAL VARIABLES & DOM SELECTOR
        ========================================== */

        const $ = id => document.getElementById(id);

        const officialRoles = [
            'gp_pradhan',
            'gp_executive_assistant',
            'bdo',
            'district_officer',
            'vpi_admin'
        ];

        const modal = $('authModal');
        const msg = $('authMessage');

        let districtsLoaded = false;


        /* =========================================
           9.3 AUTHENTICATION MESSAGE HANDLING
        ========================================== */

        function message(text, type = 'info') {
            msg.textContent = text;
            msg.className = 'message ' + type;
        }

        function clearMessage() {
            msg.textContent = '';
            msg.className = 'message';
        }


        /* =========================================
           9.4 FORM LOADING STATE
        ========================================== */

        function busy(form, on, label = 'Please wait…') {

            const button = form.querySelector('[type=submit]');

            if (!button) return;

            if (on) {
                button.dataset.label = button.textContent;
                button.textContent = label;
                button.disabled = true;
            } else {
                button.textContent = button.dataset.label || button.textContent;
                button.disabled = false;
            }
        }


        /* =========================================
           9.5 AUTHENTICATION MODAL CONTROLS
        ========================================== */

        function openModal() {
            modal.classList.add('open');
            modal.setAttribute('aria-hidden', 'false');

            document.body.classList.add('locked');

            clearMessage();
        }

        function closeModal() {
            modal.classList.remove('open');
            modal.setAttribute('aria-hidden', 'true');

            document.body.classList.remove('locked');
        }

        // Open modal from all authentication buttons.
        document.querySelectorAll('[data-open-auth]').forEach(button => {
            button.addEventListener('click', openModal);
        });

        // Close modal button.
        $('closeAuth').addEventListener('click', closeModal);

        // Close modal when clicking outside.
        modal.addEventListener('click', event => {
            if (event.target === modal) closeModal();
        });

        // Close modal using Escape key.
        document.addEventListener('keydown', event => {
            if (event.key === 'Escape') closeModal();
        });


        /* =========================================
           9.6 FOOTER YEAR
        ========================================== */

        $('year').textContent = new Date().getFullYear();


        /* =========================================
           9.7 MOBILE NAVIGATION
        ========================================== */

        $('menuToggle').addEventListener('click', () => {
            $('mainNav').classList.toggle('show');
        });

        document.querySelectorAll('#mainNav a').forEach(link => {
            link.addEventListener('click', () => {
                $('mainNav').classList.remove('show');
            });
        });


        /* =========================================
           9.8 RESIDENT / OFFICIAL TAB SWITCHING
        ========================================== */

        document.querySelectorAll('.tab').forEach(button => {

            button.addEventListener('click', () => {

                // Update active tab.
                document.querySelectorAll('.tab').forEach(tab => {
                    tab.classList.toggle('active', tab === button);
                });

                // Display the selected authentication panel.
                $('residentPanel').classList.toggle(
                    'hidden',
                    button.dataset.tab !== 'resident'
                );

                $('officialPanel').classList.toggle(
                    'hidden',
                    button.dataset.tab !== 'official'
                );

                clearMessage();
            });

        });


        /* =========================================
           9.10 LOCATION DROPDOWN UTILITIES
        ========================================== */

        // Reset dropdown and disable it.
        function resetSelect(element, placeholder) {

            element.innerHTML = '';

            const option = document.createElement('option');

            option.value = '';
            option.textContent = placeholder;

            element.append(option);
            element.disabled = true;
        }


        // Populate dropdown using Supabase records.
        function fillSelect(element, rows, placeholder) {

            element.innerHTML = '';

            const firstOption = document.createElement('option');

            firstOption.value = '';

            firstOption.textContent = rows.length
                ? placeholder
                : 'No options available';

            element.append(firstOption);

            rows.forEach(row => {

                const option = document.createElement('option');

                option.value = row.id;
                option.textContent = row.name;

                element.append(option);

            });

            element.disabled = !rows.length;
        }


        /* =========================================
           9.11 FETCH LOCATION DATA FROM SUPABASE
        ========================================== */

        async function options(table, filters = []) {

            let query = db
                .from(table)
                .select('id,name')
                .order('name', { ascending: true });

            filters.forEach(([column, value]) => {
                query = query.eq(column, value);
            });

            const { data, error } = await query;

            if (error) throw error;

            return data || [];
        }


        /* =========================================
           9.12 LOAD DISTRICTS
        ========================================== */

        async function loadDistricts() {

            if (districtsLoaded) return;

            const element = $('districtSelect');

            element.innerHTML = '<option value="">Loading districts…</option>';
            element.disabled = true;

            try {

                const districts = await options('districts');

                fillSelect(
                    element,
                    districts,
                    'Select district'
                );

                districtsLoaded = true;

            } catch (error) {

                element.innerHTML = '<option value="">Could not load districts</option>';

                message(
                    'Could not load districts: ' + error.message,
                    'error'
                );

            }
        }


        /* =========================================
           9.13 LOAD BLOCKS BASED ON DISTRICT
        ========================================== */

        $('districtSelect').addEventListener('change', async event => {

            const id = event.target.value;

            resetSelect(
                $('blockSelect'),
                id ? 'Loading blocks…' : 'Select district first'
            );

            resetSelect(
                $('gpSelect'),
                'Select block first'
            );

            resetSelect(
                $('villageSelect'),
                'Select Gram Panchayat first'
            );

            if (!id) return;

            try {

                const blocks = await options(
                    'blocks',
                    [['district_id', id]]
                );

                fillSelect(
                    $('blockSelect'),
                    blocks,
                    'Select block'
                );

            } catch (error) {

                message(
                    'Could not load blocks: ' + error.message,
                    'error'
                );

            }

        });


        /* =========================================
           9.14 LOAD GRAM PANCHAYATS BASED ON BLOCK
        ========================================== */

        $('blockSelect').addEventListener('change', async event => {

            const id = event.target.value;

            resetSelect(
                $('gpSelect'),
                id ? 'Loading Gram Panchayats…' : 'Select block first'
            );

            resetSelect(
                $('villageSelect'),
                'Select Gram Panchayat first'
            );

            if (!id) return;

            try {

                const gramPanchayats = await options(
                    'gram_panchayats',
                    [['block_id', id]]
                );

                fillSelect(
                    $('gpSelect'),
                    gramPanchayats,
                    'Select Gram Panchayat'
                );

            } catch (error) {

                message(
                    'Could not load Gram Panchayats: ' + error.message,
                    'error'
                );

            }

        });


        /* =========================================
           9.15 LOAD VILLAGES BASED ON GRAM PANCHAYAT
        ========================================== */

        $('gpSelect').addEventListener('change', async event => {

            const id = event.target.value;

            resetSelect(
                $('villageSelect'),
                id ? 'Loading villages…' : 'Select Gram Panchayat first'
            );

            if (!id) return;

            try {

                // Filter by Gram Panchayat UUID.
                // Do not deduplicate village names.
                // Identical names under different GPs remain separate.

                const villages = await options(
                    'villages',
                    [['gram_panchayat_id', id]]
                );

                fillSelect(
                    $('villageSelect'),
                    villages,
                    'Select village'
                );

            } catch (error) {

                message(
                    'Could not load villages: ' + error.message,
                    'error'
                );

            }

        });


        /* =========================================
           9.16 FETCH USER PROFILE
        ========================================== */

        async function profileFor(userId) {

            const { data, error } = await db
                .from('profiles')
                .select('*')
                .eq('id', userId)
                .maybeSingle();

            if (error) throw error;

            return data;
        }


        /* =========================================
           9.17 ROLE-BASED DASHBOARD ROUTING
        ========================================== */

        const dashboardRoles = {
            resident: {
                label: 'Resident Dashboard', eyebrow: 'RESIDENT SPACE',
                title: 'Welcome to your GramSathi account',
                description: 'Your community space is being prepared.',
                cardTitle: "We're working on your Resident Dashboard",
                cardDescription: 'Complete your profile to access resident services.'
            },
            gp_pradhan: {
                label: 'Gram Panchayat Pradhan', eyebrow: 'GRAM PANCHAYAT ADMINISTRATION',
                title: 'Gram Panchayat Dashboard',
                description: 'Monitor your Panchayat, villages and resident activity.',
                cardTitle: 'Gram Panchayat overview',
                cardDescription: 'Your workspace shows records for the Gram Panchayat assigned to your account.'
            },
            gp_executive_assistant: {
                label: 'Gram Panchayat Executive Assistant', eyebrow: 'GRAM PANCHAYAT OPERATIONS',
                title: 'Executive Assistant Dashboard',
                description: 'Manage Panchayat records and support day-to-day administration.',
                cardTitle: 'Panchayat operations',
                cardDescription: 'Your workspace shows records for the Gram Panchayat assigned to your account.'
            },
            bdo: {
                label: 'Block Development Officer', eyebrow: 'BLOCK ADMINISTRATION',
                title: 'Block Development Dashboard',
                description: 'Monitor Gram Panchayats and village-level records in your block.',
                cardTitle: 'Block overview',
                cardDescription: 'Your workspace is scoped to the block assigned to your account.'
            },
            district_officer: {
                label: 'District Officer', eyebrow: 'DISTRICT ADMINISTRATION',
                title: 'District Monitoring Dashboard',
                description: 'Review block, Panchayat and village coverage across your district.',
                cardTitle: 'District overview',
                cardDescription: 'Your workspace is scoped to the district assigned to your account.'
            },
            vpi_admin: {
                label: 'GramSathi Administrator', eyebrow: 'PLATFORM ADMINISTRATION',
                title: 'VPI Administration Dashboard',
                description: 'Oversee platform coverage and official account administration.',
                cardTitle: 'Platform overview',
                cardDescription: 'Your workspace provides a system-wide summary.'
            }
        };

        const officialDashboardConfig = {
            gp_pradhan: {
                scope: 'Gram Panchayat', tasks: ['Review village coverage and Panchayat records', 'Monitor resident profile submissions in your Panchayat', 'Coordinate local development priorities', 'Review public notices and community updates'],
                metrics: [['villages', 'Villages'], ['residents', 'Resident profiles']]
            },
            gp_executive_assistant: {
                scope: 'Gram Panchayat', tasks: ['Maintain Panchayat and village records', 'Review resident profile submissions in your Panchayat', 'Support administrative reporting', 'Prepare information for Panchayat meetings'],
                metrics: [['villages', 'Villages'], ['residents', 'Resident profiles']]
            },
            bdo: {
                scope: 'Block', tasks: ['Monitor Gram Panchayat coverage in your block', 'Review village and resident records', 'Coordinate Panchayat-level reporting', 'Track block-level administrative progress'],
                metrics: [['panchayats', 'Gram Panchayats'], ['villages', 'Villages'], ['residents', 'Resident profiles']]
            },
            district_officer: {
                scope: 'District', tasks: ['Review block-wise coverage', 'Monitor Gram Panchayat and village records', 'Review district-level resident registration coverage', 'Coordinate district monitoring and reporting'],
                metrics: [['blocks', 'Blocks'], ['panchayats', 'Gram Panchayats'], ['villages', 'Villages'], ['residents', 'Resident profiles']]
            },
            vpi_admin: {
                scope: 'Platform-wide', tasks: ['Provision official accounts and assign their jurisdiction', 'Review district, block, Panchayat and village coverage', 'Maintain platform access and governance', 'Monitor overall resident registration'],
                metrics: [['districts', 'Districts'], ['blocks', 'Blocks'], ['panchayats', 'Gram Panchayats'], ['villages', 'Villages'], ['residents', 'Resident profiles']]
            }
        };

        const RESIDENT_DOC_BUCKET = 'resident-documents';
        let currentResidentProfile = null;
        let currentResidentUser = null;

        function residentProfileComplete(profile) {
            return Boolean(profile && profile.full_name && profile.mobile_number && profile.district_id && profile.block_id && profile.gram_panchayat_id && profile.village_id && (profile.document_path || profile.document_url));
        }

        function setProfileMessage(text, type = 'info') {
            const el = $('profileFormMessage');
            if (!el) return;
            el.textContent = text;
            el.className = 'message ' + type;
        }

        async function openResidentProfile(profile, user) {
            currentResidentProfile = profile;
            currentResidentUser = user;
            $('dashboardContentCard').classList.add('hidden');
            $('residentDashboard').classList.add('hidden');
            $('residentProfileGate').classList.remove('hidden');
            $('dashboardTitle').textContent = 'Complete your resident profile';
            $('dashboardDescription').textContent = 'A few details are required before you can use GramSathi.';
            $('dashboardRoleLabel').textContent = 'Resident Profile';
            $('dashboardEyebrow').textContent = 'PROFILE SETUP';
            $('profileFullName').value = profile?.full_name || user?.user_metadata?.full_name || user?.user_metadata?.name || '';
            $('profileMobile').value = profile?.mobile_number || '';
            await loadDistricts();
            if (profile?.district_id) {
                $('districtSelect').value = profile.district_id;
                $('districtSelect').dispatchEvent(new Event('change'));
                await new Promise(resolve => setTimeout(resolve, 250));
                if (profile.block_id) {
                    $('blockSelect').value = profile.block_id;
                    $('blockSelect').dispatchEvent(new Event('change'));
                    await new Promise(resolve => setTimeout(resolve, 250));
                }
                if (profile.gram_panchayat_id) {
                    $('gpSelect').value = profile.gram_panchayat_id;
                    $('gpSelect').dispatchEvent(new Event('change'));
                    await new Promise(resolve => setTimeout(resolve, 250));
                }
                if (profile.village_id) $('villageSelect').value = profile.village_id;
            }
        }

        function showResidentDashboard(profile, user) {
            currentResidentProfile = profile;
            currentResidentUser = user;
            const verified = profile.verification_status === 'verified';
            $('residentProfileGate').classList.add('hidden');
            $('dashboardContentCard').classList.add('hidden');
            $('residentDashboard').classList.remove('hidden');
            $('dashboardTitle').textContent = `Welcome, ${profile.full_name || 'Resident'}`;
            $('dashboardDescription').textContent = 'Your GramSathi community dashboard.';
            $('dashboardEyebrow').textContent = 'RESIDENT SPACE';
            $('dashboardRoleLabel').textContent = 'Resident Dashboard';
            $('residentVerificationBanner').classList.toggle('pending', !verified);
            $('residentVerificationBanner').classList.toggle('verified', verified);
            $('residentVerificationTitle').textContent = verified ? 'Identity verified' : 'Identity verification pending';
            $('residentVerificationText').textContent = verified ? 'Your resident services are now available.' : 'You can view public information. Complaints and requests unlock after your identity is verified.';
            $('residentVerificationBadge').textContent = verified ? 'Verified' : (profile.verification_status || 'Pending').replaceAll('_', ' ');
            $('residentAccountSummary').textContent = verified ? 'Verified' : 'Pending verification';
            $('residentLocationSummary').textContent = [profile.village_name, profile.gram_panchayat_name, profile.block_name].filter(Boolean).join(' · ') || 'Location saved';
            document.querySelectorAll('[data-resident-section="complaints"], [data-resident-section="submissions"]').forEach(btn => {
                btn.querySelector('.feature-lock')?.classList.toggle('hidden', verified);
            });
            $('residentSectionDetail').classList.add('hidden');
            $('residentDashboard').querySelector('.resident-feature-grid').classList.remove('hidden');
        }

        function openResidentSection(section) {
            const verified = currentResidentProfile?.verification_status === 'verified';
            const restricted = ['complaints', 'submissions'].includes(section);
            if (restricted && !verified) {
                showResidentNotice('Please verify your identity', 'Your identity verification is pending. You can access Complaints & Requests after your profile is verified by the concerned authority.');
                return;
            }
            const titles = { announcements: 'Announcements', schemes: 'Government Schemes', village: 'My Village', panchayat: 'Gram Panchayat', development: 'Development Works', complaints: 'Complaints & Requests', submissions: 'My Submissions', events: 'Events & Meetings', emergency: 'Emergency Contacts', documents: 'Important Documents', profile: 'My Profile' };
            const descriptions = { announcements: 'Public notices and local updates will be displayed here when published by GramSathi officials.', schemes: 'Information about applicable central and West Bengal government schemes will be displayed here.', village: 'Your village profile, public facilities and local information.', panchayat: 'Gram Panchayat details, office information and public representatives.', development: 'Public development projects and their progress in your area.', complaints: 'Choose whether you want to raise a complaint or request a Panchayat service.', submissions: 'Your submitted complaints and service requests with their latest status.', events: 'Gram Sabha schedules, public meetings and community events.', emergency: 'Important emergency and public service contact numbers for your area.', documents: 'Publicly available forms, notices and useful documents.', profile: 'Your saved resident details and identity verification status.' };
            $('residentDashboard').querySelector('.resident-feature-grid').classList.add('hidden');
            $('residentSectionDetail').classList.remove('hidden');
            $('residentDetailTitle').textContent = titles[section] || 'Information';
            $('residentDetailText').textContent = descriptions[section] || '';
            const content = $('residentDetailContent');
            content.innerHTML = '';
            if (section === 'complaints') {
                content.innerHTML = '<div class="resident-action-grid"><button class="resident-action" type="button" data-resident-action="complaint">📝 Raise a Complaint</button><button class="resident-action" type="button" data-resident-action="request">📄 Request a Service</button></div><p class="hint">Choose the type of submission you want to make. The submission form will be connected in the next service module.</p>';
            } else if (section === 'profile') {
                const p = currentResidentProfile || {};
                content.innerHTML = `<div class="resident-profile-read"><p><b>Full name:</b> ${escapeHtml(p.full_name || '—')}</p><p><b>Mobile:</b> ${escapeHtml(p.mobile_number || '—')}</p><p><b>Verification:</b> ${escapeHtml(p.verification_status || 'pending')}</p><p><b>Document:</b> ${escapeHtml(p.document_type || 'Not submitted')}</p></div>`;
            } else {
                content.innerHTML = '<div class="resident-empty-state">This section is ready for public information to be added from the GramSathi administration dashboard.</div>';
            }
        }

        function escapeHtml(value) {
            return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
        }

        function showResidentNotice(title, body) {
            const old = document.getElementById('residentAccessNotice');
            if (old) old.remove();
            const notice = document.createElement('div');
            notice.id = 'residentAccessNotice';
            notice.className = 'resident-access-notice';
            notice.innerHTML = `<strong>${escapeHtml(title)}</strong><p>${escapeHtml(body)}</p><button type="button" class="btn outline">Close</button>`;
            notice.querySelector('button').addEventListener('click', () => notice.remove());
            document.body.appendChild(notice);
        }

        $('residentProfileForm').addEventListener('submit', async event => {
            event.preventDefault();
            const form = event.currentTarget;
            const file = $('residentDocument').files[0];
            if (!file) return setProfileMessage('Please select a supporting document.', 'error');
            if (file.size > 5 * 1024 * 1024) return setProfileMessage('The document must be 5 MB or smaller.', 'error');
            if (!['application/pdf', 'image/jpeg', 'image/png'].includes(file.type)) return setProfileMessage('Upload a PDF, JPG or PNG file.', 'error');
            const location = { district_id: $('districtSelect').value, block_id: $('blockSelect').value, gram_panchayat_id: $('gpSelect').value, village_id: $('villageSelect').value };
            if (Object.values(location).some(value => !value)) return setProfileMessage('Please select district, block, Gram Panchayat and village.', 'error');
            const mobile = $('profileMobile').value.trim();
            if (!/^\+?[0-9]{10,15}$/.test(mobile)) return setProfileMessage('Enter a valid mobile number (10–15 digits).', 'error');
            const submit = form.querySelector('[type=submit]');
            submit.disabled = true; submit.textContent = 'Uploading securely…';
            try {
                const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
                const path = `${currentResidentUser.id}/${Date.now()}-${safeName}`;
                const { error: uploadError } = await db.storage.from(RESIDENT_DOC_BUCKET).upload(path, file, { upsert: true, contentType: file.type });
                if (uploadError) throw uploadError;
                const update = { full_name: $('profileFullName').value.trim(), mobile_number: mobile, ...location, district_name: $('districtSelect').selectedOptions[0]?.textContent || '', block_name: $('blockSelect').selectedOptions[0]?.textContent || '', gram_panchayat_name: $('gpSelect').selectedOptions[0]?.textContent || '', village_name: $('villageSelect').selectedOptions[0]?.textContent || '', document_type: $('residentDocumentType').value, document_path: path, profile_completed_at: new Date().toISOString() };
                const { data, error } = await db.from('profiles').update(update).eq('id', currentResidentUser.id).select('*').single();
                if (error) throw error;
                currentResidentProfile = data;
                setProfileMessage('Your profile has been submitted. You can now view your Resident Dashboard while identity verification is pending.', 'success');
                setTimeout(() => showResidentDashboard(data, currentResidentUser), 700);
            } catch (error) {
                console.error('Resident profile submission:', error);
                setProfileMessage('Could not submit your profile: ' + error.message + '. Check the database columns and private storage setup SQL supplied with these files.', 'error');
            } finally {
                submit.disabled = false; submit.textContent = 'Submit profile for verification';
            }
        });

        document.querySelectorAll('[data-resident-section]').forEach(button => button.addEventListener('click', () => openResidentSection(button.dataset.residentSection)));
        $('residentDetailBack').addEventListener('click', () => {
            $('residentSectionDetail').classList.add('hidden');
            $('residentDashboard').querySelector('.resident-feature-grid').classList.remove('hidden');
        });

        async function countRows(table, column, value) {
            let query = db.from(table).select('id', { count: 'exact', head: true });
            if (column && value) query = query.eq(column, value);
            const { count, error } = await query;
            if (error) return { count: null, error: error.message };
            return { count: count ?? 0, error: null };
        }

        async function loadOfficialDashboard(profile) {
            await initialiseMediaAdmin(profile);

            // Load residents visible to this official account
            await loadResidentManagement(profile);
            

            const role = profile.role;
            const config = officialDashboardConfig[role];
            if (!config) return;
            $('officialDashboard').classList.remove('hidden');
            $('dashboardContentCard').classList.add('hidden');
            $('officialScopeTitle').textContent = config.scope + ' workspace';

            const scopeParts = [];
            if (profile.district_name) scopeParts.push(profile.district_name);
            if (profile.block_name) scopeParts.push(profile.block_name);
            if (profile.gram_panchayat_name) scopeParts.push(profile.gram_panchayat_name);
            $('officialScopeDescription').textContent = scopeParts.length ? scopeParts.join('  ›  ') : 'No jurisdiction has been assigned to this official account yet.';
            $('officialTasksTitle').textContent = role === 'vpi_admin' ? 'Administration responsibilities' : 'Your responsibilities';
            $('officialTaskList').innerHTML = config.tasks.map(task => `<li>${escapeHtml(task)}</li>`).join('');
            $('officialAccessNote').textContent = role === 'vpi_admin'
                ? 'System-wide summary. Sensitive records remain subject to backend permissions.'
                : 'Records are requested using your assigned jurisdiction. Supabase Row Level Security must enforce the same scope.';

            let scopeColumn = null, scopeValue = null;
            if (role === 'gp_pradhan' || role === 'gp_executive_assistant') { scopeColumn = 'gram_panchayat_id'; scopeValue = profile.gram_panchayat_id; }
            if (role === 'bdo') { scopeColumn = 'block_id'; scopeValue = profile.block_id; }
            if (role === 'district_officer') { scopeColumn = 'district_id'; scopeValue = profile.district_id; }

            const definitions = {
                districts: ['districts', null, null],
                blocks: ['blocks', role === 'district_officer' ? 'district_id' : null, role === 'district_officer' ? profile.district_id : null],
                panchayats: ['gram_panchayats', role === 'gp_pradhan' || role === 'gp_executive_assistant' ? 'id' : role === 'bdo' ? 'block_id' : role === 'district_officer' ? 'district_id' : null, role === 'gp_pradhan' || role === 'gp_executive_assistant' ? profile.gram_panchayat_id : role === 'bdo' ? profile.block_id : role === 'district_officer' ? profile.district_id : null],
                villages: ['villages', scopeColumn, scopeValue],
                residents: ['profiles', scopeColumn, scopeValue]
            };
            const allowedKeys = config.metrics.map(item => item[0]);
            const results = await Promise.all(allowedKeys.map(async key => {
                const [table, column, value] = definitions[key];
                return [key, await countRows(table, column, value)];
            }));
            const resultMap = Object.fromEntries(results);
            $('officialMetricGrid').innerHTML = config.metrics.map(([key, label]) => {
                const result = resultMap[key] || { count: null, error: 'Not available' };
                const display = result.count === null ? '—' : result.count.toLocaleString('en-IN');
                const note = result.error ? 'Not available under current database permissions' : 'Records in assigned scope';
                return `<article class="official-metric"><span>${escapeHtml(label)}</span><strong>${display}</strong><small>${escapeHtml(note)}</small></article>`;
            }).join('');

            const areaItems = [];
            if (profile.district_name) areaItems.push(['District', profile.district_name]);
            if (profile.block_name) areaItems.push(['Block', profile.block_name]);
            if (profile.gram_panchayat_name) areaItems.push(['Gram Panchayat', profile.gram_panchayat_name]);
            $('officialAreaList').innerHTML = areaItems.length
                ? areaItems.map(([label, value]) => `<div><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join('')
                : '<p>Jurisdiction assignment is required. Contact the VPI Administrator.</p>';

            const missingScope = (role === 'gp_pradhan' || role === 'gp_executive_assistant') && !profile.gram_panchayat_id || role === 'bdo' && !profile.block_id || role === 'district_officer' && !profile.district_id;
            $('officialDashboardNote').textContent = missingScope
                ? 'Your role is verified, but its jurisdiction has not been assigned. Ask the VPI Administrator to assign your district, block or Gram Panchayat.'
                : 'Counts reflect the records currently visible to this account. Database permissions must enforce jurisdiction restrictions; hiding data in the interface alone is not security.';
        }

        function showDashboard(profile, user) {
            const role = profile?.role;
            const config = dashboardRoles[role];

            if (!config) {
                throw new Error('Your account has an unsupported GramSathi role. Please contact the administrator.');
            }

            $('dashboardUserName').textContent = profile.full_name || user?.email || 'GramSathi user';
            $('dashboardRoleLabel').textContent = config.label;
            $('dashboardEyebrow').textContent = config.eyebrow;
            $('dashboardTitle').textContent = config.title;
            $('dashboardDescription').textContent = config.description;
            $('dashboardCardTitle').textContent = config.cardTitle;
            $('dashboardCardDescription').textContent = config.cardDescription;
            $('officialDashboard').classList.add('hidden');
            if (role === 'resident') {
                $('dashboardContentCard').classList.remove('hidden');
                $('residentProfileGate').classList.add('hidden');
                $('residentDashboard').classList.add('hidden');
                if (residentProfileComplete(profile)) showResidentDashboard(profile, user);
                else openResidentProfile(profile, user);
            } else {
                $('residentProfileGate').classList.add('hidden');
                $('residentDashboard').classList.add('hidden');
                loadOfficialDashboard(profile).catch(error => {
                    console.error('Official dashboard data error:', error);
                    $('officialDashboardNote').textContent = 'Dashboard opened, but some records could not be loaded. Please check database permissions.';
                });
            }

            // Keep the dashboard route in the URL so it can be restored after refresh.
            if (window.location.hash !== '#dashboard') {
                window.history.replaceState(
                    null,
                    '',
                    window.location.pathname + window.location.search + '#dashboard'
                );
            }

            closeModal();
            document.querySelector('body').classList.add('dashboard-active');
            $('dashboardView').classList.remove('hidden');
            window.scrollTo({ top: 0, behavior: 'instant' });
        }

        function hideDashboard() {
            $('dashboardView').classList.add('hidden');
            $('officialDashboard').classList.add('hidden');
            document.body.classList.remove('dashboard-active');
            window.history.replaceState(
                null,
                '',
                window.location.pathname + window.location.search
            );
        }

        async function restoreDashboard(session) {
            if (!session?.user || window.location.hash !== '#dashboard') return;

            try {
                const profile = await profileFor(session.user.id);

                if (!profile || !dashboardRoles[profile.role]) {
                    await db.auth.signOut();
                    hideDashboard();
                    openModal();
                    message('Your GramSathi profile could not be verified. Please sign in again or contact the administrator.', 'error');
                    return;
                }

                if (
                    profile.role !== 'resident' &&
                    profile.verification_status !== 'verified'
                ) {
                    await db.auth.signOut();
                    hideDashboard();
                    openModal();
                    message('This official account is not verified. Contact the GramSathi administrator.', 'error');
                    return;
                }

                showDashboard(profile, session.user);
            } catch (error) {
                console.error('Dashboard restore error:', error);
                hideDashboard();
                openModal();
                message('Could not load your dashboard: ' + error.message, 'error');
            }
        }

        $('dashboardLogout').addEventListener('click', async () => {
            const button = $('dashboardLogout');
            button.disabled = true;
            button.textContent = 'Signing out…';

            try {
                const { error } = await db.auth.signOut();
                if (error) throw error;

                hideDashboard();
                openModal();

                // Return to the resident login view after sign-out.
                document.querySelectorAll('.tab').forEach(tab => {
                    tab.classList.toggle('active', tab.dataset.tab === 'resident');
                });
                $('residentPanel').classList.remove('hidden');
                $('officialPanel').classList.add('hidden');

                message('You have been signed out successfully.', 'success');
            } catch (error) {
                message('Sign out failed: ' + error.message, 'error');
            } finally {
                button.disabled = false;
                button.textContent = 'Sign out';
            }
        });



        /* =========================================
           9.17 VALIDATE RESIDENT / OFFICIAL LOGIN
        ========================================== */

        async function validateLogin(user, kind) {

            let profile;

            try {

                profile = await profileFor(user.id);

            } catch (error) {

                await db.auth.signOut();

                throw new Error(
                    'Could not check your VPI profile: ' + error.message
                );

            }

            // Check profile existence.
            if (!profile) {

                await db.auth.signOut();

                throw new Error(
                    'VPI profile not found. Please contact the administrator.'
                );

            }


            // Validate resident role.
            if (kind === 'resident' && profile.role !== 'resident') {

                await db.auth.signOut();

                throw new Error(
                    'This account is not registered as a resident.'
                );

            }


            // Validate official role.
            if (
                kind === 'official' &&
                (
                    !officialRoles.includes(profile.role) ||
                    profile.role !== $('officialRole').value
                )
            ) {

                await db.auth.signOut();

                throw new Error(
                    'The selected official role does not match the role assigned to this account.'
                );

            }


            // Verify official account status.
            if (
                kind === 'official' &&
                profile.verification_status !== 'verified'
            ) {

                await db.auth.signOut();

                throw new Error(
                    'This official account is not verified. Contact the VPI administrator.'
                );

            }


            // Display login success message.
            if (
                kind === 'resident' &&
                profile.verification_status !== 'verified'
            ) {

                message(
                    'Login successful. Your account is awaiting verification; some features may remain restricted.',
                    'success'
                );

            } else {

                message(
                    'Welcome' +
                    (profile.full_name ? ', ' + profile.full_name : '') +
                    '! Login successful.',
                    'success'
                );

            }

            // Open the workspace using the role stored in the Supabase profile.
            showDashboard(profile, user);

        }


        /* =========================================
           9.18 RESIDENT GOOGLE OAUTH LOGIN
        ========================================== */

        $('googleLogin').addEventListener('click', async () => {

            clearMessage();

            const button = $('googleLogin');
            button.disabled = true;
            button.dataset.originalText = button.innerHTML;
            button.innerHTML = '<span class="google-mark">G</span> Redirecting to Google…';

            try {

                // Remember that this redirect was initiated by the resident Google button.
                // This lets the callback validate the resulting VPI profile.
                sessionStorage.setItem('vpi_google_login', '1');

                const { error } = await db.auth.signInWithOAuth({
                    provider: 'google',
                    options: {
                        redirectTo: window.location.origin,
                        queryParams: {
                            prompt: 'select_account'
                        }
                    }
                });

                if (error) throw error;

            } catch (error) {

                sessionStorage.removeItem('vpi_google_login');
                message('Google sign-in could not start: ' + error.message, 'error');

                button.disabled = false;
                button.innerHTML = button.dataset.originalText || 'Continue with Google';

            }

        });


        /* =========================================
           9.21 OFFICIAL LOGIN
        ========================================== */

        $('officialLoginForm').addEventListener('submit', async event => {

            event.preventDefault();

            const form = event.currentTarget;

            clearMessage();

            busy(form, true, 'Signing in…');

            try {

                const { data, error } = await db.auth.signInWithPassword({

                    email: $('officialEmail').value.trim(),

                    password: $('officialPassword').value

                });

                if (error) throw error;

                await validateLogin(data.user, 'official');

            } catch (error) {

                message(error.message, 'error');

            } finally {

                busy(form, false);

            }

        });


        /* =========================================
           9.23 SUPABASE AUTH STATE LISTENER
        ========================================== */

        let googleReturnHandled = false;
        let dashboardRestoreStarted = false;

        async function handleGoogleReturn(session) {
            if (
                googleReturnHandled ||
                !session ||
                sessionStorage.getItem('vpi_google_login') !== '1'
            ) {
                return;
            }

            googleReturnHandled = true;
            sessionStorage.removeItem('vpi_google_login');

            // Defer profile work until Supabase finishes its auth-state callback.
            setTimeout(async () => {
                try {
                    await validateLogin(session.user, 'resident');
                } catch (error) {
                    openModal();
                    message(error.message, 'error');
                }
            }, 0);
        }

        db.auth.onAuthStateChange((event, session) => {
            if (event === 'SIGNED_IN' || event === 'INITIAL_SESSION') {
                if (sessionStorage.getItem('vpi_google_login') === '1') {
                    handleGoogleReturn(session);
                } else if (
                    event === 'INITIAL_SESSION' &&
                    session &&
                    window.location.hash === '#dashboard' &&
                    !dashboardRestoreStarted
                ) {
                    dashboardRestoreStarted = true;
                    setTimeout(() => restoreDashboard(session), 0);
                }
            }

            if (event === 'SIGNED_OUT') {
                clearMessage();
            }
        });


        /* =========================================
           9.24 PUBLIC MEDIA + TEAM VIEW
           Public records are filtered by is_active in Supabase.
        ========================================== */
        const SITE_MEDIA_BUCKET = 'vpi-site-media';
        const SITE_MEDIA_TABLE = 'site_media';
        const PUBLIC_MEDIA_FALLBACK = {
            dooars_kanya: 'https://placehold.co/900x620/e8f1eb/176b45?text=Dooars+Kanya',
            chief_minister: 'https://placehold.co/900x620/e8f1eb/176b45?text=Chief+Minister'
        };

        async function siteMediaUrl(path) {
            const { data, error } = await db.storage.from(SITE_MEDIA_BUCKET).createSignedUrl(path, 3600);
            if (error) {
                console.warn('Could not create image URL:', error.message);
                return '';
            }
            return data?.signedUrl || '';
        }

        function mediaSafeText(value) {
            return String(value ?? '').replace(/[&<>"']/g, char => ({
                '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
            })[char]);
        }

        async function loadPublicSiteMedia() {
            const { data, error } = await db.from(SITE_MEDIA_TABLE)
                .select('id, category, title, storage_path, alt_text, display_order')
                .eq('is_active', true)
                .order('display_order', { ascending: true });
            if (error) {
                console.warn('Public media could not be loaded:', error.message);
                return;
            }
            const rows = data || [];
            const firstOf = category => rows.find(item => item.category === category);
            const dk = firstOf('dooars_kanya');
            const cm = firstOf('chief_minister');
            if (dk) {
                $('dooarsKanyaImage').src = (await siteMediaUrl(dk.storage_path)) || PUBLIC_MEDIA_FALLBACK.dooars_kanya;
                $('dooarsKanyaImage').alt = dk.alt_text || dk.title || 'Dooars Kanya, Alipurduar';
            }
            if (cm) {
                $('chiefMinisterImage').src = (await siteMediaUrl(cm.storage_path)) || PUBLIC_MEDIA_FALLBACK.chief_minister;
                $('chiefMinisterImage').alt = cm.alt_text || cm.title || 'Shri Suvendu Adhikari';
            }
            const gallery = rows.filter(item => item.category === 'gallery');
            const galleryCards = await Promise.all(gallery.map(async item => ({
                ...item, imageUrl: await siteMediaUrl(item.storage_path)
            })));
            $('publicGallery').innerHTML = galleryCards.length ? galleryCards.map(item => `
                <figure class="gallery-item">
                    <img src="${mediaSafeText(item.imageUrl)}" alt="${mediaSafeText(item.alt_text || item.title)}" loading="lazy">
                    <figcaption>${mediaSafeText(item.title)}</figcaption>
                </figure>`).join('') : '<div class="gallery-empty">Gallery photos will appear here when added by the VPI administrator.</div>';

            await renderTeamMembers(rows.filter(item => item.category === 'team'));
        }
        async function renderTeamMembers(teamMedia) {
            const defaults = [
                { title: 'Hirakjyoti Das', role: 'Programmer & Developer', initials: 'HD' },
                { title: 'Monalisa Parvin', role: 'Tester & Deployment', initials: 'MP' }
            ];
            const team = await Promise.all(defaults.map(async person => {
                const photo = teamMedia.find(item => item.title.toLowerCase() === person.title.toLowerCase());
                return { ...person, photo, imageUrl: photo ? await siteMediaUrl(photo.storage_path) : '' };
            }));
            $('teamMembers').innerHTML = team.map(person => `
                <article class="team-card">
                    ${person.imageUrl
                    ? `<img class="team-photo" src="${mediaSafeText(person.imageUrl)}" alt="${mediaSafeText(person.photo.alt_text || person.title)}" loading="lazy">`
                    : `<div class="team-photo-placeholder" aria-label="Photo placeholder">${person.initials}</div>`}
                    <h2>${mediaSafeText(person.title)}</h2>
                    <p>${mediaSafeText(person.role)}</p>
                </article>`).join('');
        }
        function openTeamPage(event) {
            if (event) event.preventDefault();
            if (document.body.classList.contains('dashboard-active')) return;
            document.querySelector('.header').classList.add('hidden');
            document.querySelector('body > main').classList.add('hidden');
            document.querySelector('footer').classList.add('hidden');
            $('teamPage').classList.remove('hidden');
            window.history.replaceState(null, '', window.location.pathname + window.location.search + '#team');
            window.scrollTo({ top: 0, behavior: 'instant' });
        }

        function closeTeamPage() {
            $('teamPage').classList.add('hidden');
            document.querySelector('.header').classList.remove('hidden');
            document.querySelector('body > main').classList.remove('hidden');
            document.querySelector('footer').classList.remove('hidden');
            if (window.location.hash === '#team') {
                window.history.replaceState(null, '', window.location.pathname + window.location.search + '#home');
            }
            window.scrollTo({ top: 0, behavior: 'instant' });
        }

        $('meetTeamLink').addEventListener('click', openTeamPage);
        $('teamBackButton').addEventListener('click', closeTeamPage);
        $('teamHomeBrand').addEventListener('click', event => { event.preventDefault(); closeTeamPage(); });
        $('year').textContent = new Date().getFullYear();
        loadPublicSiteMedia().catch(error => console.warn('Media load failed:', error));

        /* =========================================
           9.25 ADMIN-ONLY MEDIA MANAGEMENT
           RLS is the actual security boundary; UI checks are supplemental.
        ========================================== */
        let activeMediaAdminProfile = null;

        function setMediaAdminMessage(text, isError = false) {
            const el = $('mediaAdminMessage');
            if (!el) return;
            el.textContent = text;
            el.className = 'media-admin-message ' + (isError ? 'error' : 'success');
        }

        async function loadAdminSiteMedia() {
            const { data, error } = await db.from(SITE_MEDIA_TABLE)
                .select('id, category, title, storage_path, alt_text, display_order, is_active, created_at')
                .order('created_at', { ascending: false });
            if (error) throw error;
            const list = $('siteMediaAdminList');
            if (!data?.length) {
                list.innerHTML = '<p>No website photos have been uploaded yet.</p>';
                return;
            }
            const enriched = await Promise.all(data.map(async item => ({
                ...item, imageUrl: await siteMediaUrl(item.storage_path)
            })));
            list.innerHTML = enriched.map(item => `
                <article class="site-media-admin-item" data-media-id="${mediaSafeText(item.id)}">
                    <img src="${mediaSafeText(item.imageUrl)}" alt="">
                    <div class="site-media-admin-copy">
                        <strong>${mediaSafeText(item.title)}</strong>
                        <span>${mediaSafeText(item.category)} · ${item.is_active ? 'Public' : 'Hidden'} · Order ${item.display_order}</span>
                    </div>
                    <div class="site-media-admin-actions">
                        <button type="button" class="btn outline media-replace" data-id="${mediaSafeText(item.id)}" data-path="${mediaSafeText(item.storage_path)}" data-category="${mediaSafeText(item.category)}">Replace</button>
                        <button type="button" class="btn outline media-toggle" data-id="${mediaSafeText(item.id)}" data-active="${item.is_active ? '1' : '0'}">${item.is_active ? 'Hide' : 'Show'}</button>
                        <button type="button" class="btn outline media-delete" data-id="${mediaSafeText(item.id)}" data-path="${mediaSafeText(item.storage_path)}">Delete</button>
                    </div>
                </article>`).join('');

            list.querySelectorAll('.media-replace').forEach(button => {
                button.addEventListener('click', () => {
                    const picker = document.createElement('input');
                    picker.type = 'file';
                    picker.accept = 'image/jpeg,image/png,image/webp';
                    picker.addEventListener('change', async () => {
                        const file = picker.files?.[0];
                        if (!file) return;
                        if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024) {
                            return setMediaAdminMessage('Choose a JPG, PNG or WebP image up to 5 MB.', true);
                        }
                        try {
                            const ext = file.name.split('.').pop().toLowerCase().replace(/[^a-z0-9]/g, '') || 'jpg';
                            const newPath = `${button.dataset.category}/${crypto.randomUUID()}.${ext}`;
                            const { error: uploadError } = await db.storage.from(SITE_MEDIA_BUCKET).upload(newPath, file, {
                                cacheControl: '3600', upsert: false, contentType: file.type
                            });
                            if (uploadError) throw uploadError;
                            const { error: updateError } = await db.from(SITE_MEDIA_TABLE)
                                .update({ storage_path: newPath }).eq('id', button.dataset.id);
                            if (updateError) {
                                await db.storage.from(SITE_MEDIA_BUCKET).remove([newPath]);
                                throw updateError;
                            }
                            const { error: removeError } = await db.storage.from(SITE_MEDIA_BUCKET).remove([button.dataset.path]);
                            await loadAdminSiteMedia();
                            await loadPublicSiteMedia();
                            setMediaAdminMessage(removeError ? 'Photo replaced; old file cleanup needs attention.' : 'Photo replaced successfully.', Boolean(removeError));
                        } catch (error) {
                            setMediaAdminMessage(error.message || 'Photo replacement failed.', true);
                        }
                    });
                    picker.click();
                });
            });
            list.querySelectorAll('.media-toggle').forEach(button => {
                button.addEventListener('click', async () => {
                    const nextActive = button.dataset.active !== '1';
                    const { error } = await db.from(SITE_MEDIA_TABLE).update({ is_active: nextActive }).eq('id', button.dataset.id);
                    if (error) return setMediaAdminMessage(error.message, true);
                    await loadAdminSiteMedia();
                    await loadPublicSiteMedia();
                    setMediaAdminMessage('Photo visibility updated.');
                });
            });
            list.querySelectorAll('.media-delete').forEach(button => {
                button.addEventListener('click', async () => {
                    if (!window.confirm('Delete this website photo?')) return;
                    const { error: rowError } = await db.from(SITE_MEDIA_TABLE).delete().eq('id', button.dataset.id);
                    if (rowError) return setMediaAdminMessage(rowError.message, true);
                    const { error: fileError } = await db.storage.from(SITE_MEDIA_BUCKET).remove([button.dataset.path]);
                    if (fileError) setMediaAdminMessage('Photo record deleted, but storage cleanup failed: ' + fileError.message, true);
                    else setMediaAdminMessage('Photo deleted.');
                    await loadAdminSiteMedia();
                    await loadPublicSiteMedia();
                });
            });
        }

        $('siteMediaForm').addEventListener('submit', async event => {
            event.preventDefault();
            if (!activeMediaAdminProfile || activeMediaAdminProfile.role !== 'vpi_admin' ||
                activeMediaAdminProfile.verification_status !== 'verified') {
                setMediaAdminMessage('Only a verified VPI administrator can manage website photos.', true);
                return;
            }
            const file = $('mediaFile').files[0];
            if (!file) return setMediaAdminMessage('Choose an image file first.', true);
            if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) return setMediaAdminMessage('Use a JPG, PNG or WebP image.', true);
            if (file.size > 5 * 1024 * 1024) return setMediaAdminMessage('Image size must be 5 MB or less.', true);

            const button = $('mediaSaveButton');
            button.disabled = true;
            button.textContent = 'Uploading…';
            try {
                const category = $('mediaCategory').value;
                const ext = file.name.split('.').pop().toLowerCase().replace(/[^a-z0-9]/g, '') || 'jpg';
                const path = `${category}/${crypto.randomUUID()}.${ext}`;
                const { error: uploadError } = await db.storage.from(SITE_MEDIA_BUCKET).upload(path, file, {
                    cacheControl: '3600', upsert: false, contentType: file.type
                });
                if (uploadError) throw uploadError;

                const payload = {
                    category,
                    title: $('mediaTitle').value.trim(),
                    alt_text: $('mediaAlt').value.trim() || null,
                    storage_path: path,
                    display_order: Number($('mediaOrder').value || 0),
                    is_active: $('mediaActive').checked,
                    created_by: (await db.auth.getUser()).data.user?.id
                };
                const { error: insertError } = await db.from(SITE_MEDIA_TABLE).insert(payload);
                if (insertError) {
                    await db.storage.from(SITE_MEDIA_BUCKET).remove([path]);
                    throw insertError;
                }
                event.target.reset();
                $('mediaOrder').value = '0';
                $('mediaActive').checked = true;
                setMediaAdminMessage('Photo uploaded successfully.');
                await loadAdminSiteMedia();
                await loadPublicSiteMedia();
            } catch (error) {
                setMediaAdminMessage(error.message || 'Photo upload failed.', true);
            } finally {
                button.disabled = false;
                button.textContent = 'Upload photo';
            }
        });

        async function initialiseMediaAdmin(profile) {
            activeMediaAdminProfile = profile;
            const allowed = profile?.role === 'vpi_admin' && profile?.verification_status === 'verified';
            $('siteMediaManager').classList.toggle('hidden', !allowed);
            if (!allowed) return;
            try {
                await loadAdminSiteMedia();
            } catch (error) {
                setMediaAdminMessage('Could not load media manager: ' + error.message, true);
            }
        }


/* =========================================
   9.26 RESIDENT MANAGEMENT - SUPABASE
   Shared by all verified official roles
========================================== */

const RESIDENT_DOCUMENT_BUCKET = 'resident-documents';

let residentManagementProfile = null;
let residentManagementRows = [];
let selectedResidentProfile = null;


/* Display messages */

function setResidentManagementMessage(text, type = 'success') {
    const el = $('residentManagementMessage');
    if (!el) return;

    el.textContent = text;
    el.className = 'resident-management-message ' + type;
}


/* Load residents using Supabase RLS */

async function loadResidentManagement(profile) {
    residentManagementProfile = profile;

    const section = $('residentManagement');

    const permittedRoles = [
        'vpi_admin',
        'district_officer',
        'bdo',
        'gp_pradhan',
        'gp_executive_assistant'
    ];

    const allowed =
        permittedRoles.includes(profile?.role) &&
        profile?.verification_status === 'verified';

    section.classList.toggle('hidden', !allowed);

    if (!allowed) return;

    setResidentManagementMessage('Loading resident records...', 'success');

    $('residentManagementList').innerHTML = `
        <tr><td colspan="5">Loading residents...</td></tr>
    `;

    try {
        const { data, error } = await db
            .from('profiles')
            .select(`
                id,
                full_name,
                mobile_number,
                district_name,
                block_name,
                gram_panchayat_name,
                village_name,
                document_type,
                document_path,
                verification_status,
                verification_note,
                verified_at,
                verified_by,
                created_at
            `)
            .eq('role', 'resident')
            .order('created_at', { ascending: false })
            .limit(1000);

        if (error) throw error;

        residentManagementRows = data || [];

        renderResidentManagement();

        setResidentManagementMessage(
            residentManagementRows.length
                ? 'Resident records loaded successfully.'
                : 'No resident records are available in your assigned jurisdiction.',
            'success'
        );

    } catch (error) {
        console.error('Resident management error:', error);

        residentManagementRows = [];

        $('residentManagementList').innerHTML = `
            <tr>
                <td colspan="5">Could not load resident records.</td>
            </tr>
        `;

        updateResidentManagementSummary([]);

        setResidentManagementMessage(
            'Could not load residents: ' + error.message,
            'error'
        );
    }
}


/* Update resident summary cards */

function updateResidentManagementSummary(rows) {
    $('residentTotalCount').textContent = rows.length;

    $('residentPendingCount').textContent =
        rows.filter(item => item.verification_status === 'unverified').length;

    $('residentVerifiedCount').textContent =
        rows.filter(item => item.verification_status === 'verified').length;

    $('residentRejectedCount').textContent =
        rows.filter(item => item.verification_status === 'rejected').length;
}


/* Render resident list and apply search/filter */

function renderResidentManagement() {
    const search = $('residentSearch').value.trim().toLowerCase();
    const status = $('residentStatusFilter').value;

    updateResidentManagementSummary(residentManagementRows);

    const filtered = residentManagementRows.filter(resident => {
        const searchable = [
            resident.full_name,
            resident.mobile_number,
            resident.district_name,
            resident.block_name,
            resident.gram_panchayat_name,
            resident.village_name
        ].join(' ').toLowerCase();

        const matchesSearch = searchable.includes(search);

        const matchesStatus =
            status === 'all' ||
            resident.verification_status === status;

        return matchesSearch && matchesStatus;
    });

    const list = $('residentManagementList');

    if (!filtered.length) {
        list.innerHTML = `
            <tr>
                <td colspan="5">No matching resident records found.</td>
            </tr>
        `;
        return;
    }

    list.innerHTML = filtered.map(resident => {
        const id = mediaSafeText(resident.id);
        const name = mediaSafeText(resident.full_name || 'Name not provided');
        const mobile = mediaSafeText(resident.mobile_number || 'Not provided');
        const village = mediaSafeText(resident.village_name || 'Not provided');
        const currentStatus = resident.verification_status || 'unverified';

        return `
            <tr>
                <td><strong>${name}</strong></td>
                <td>${mobile}</td>
                <td>${village}</td>
                <td>
                    <span class="resident-status ${mediaSafeText(currentStatus)}">
                        ${mediaSafeText(currentStatus)}
                    </span>
                </td>
                <td>
                    <div class="resident-table-action">
                        <button type="button"
                            class="btn outline resident-view-button"
                            data-resident-id="${id}">
                            View
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');

    list.querySelectorAll('.resident-view-button').forEach(button => {
        button.addEventListener('click', () => {
            openResidentDetails(button.dataset.residentId);
        });
    });
}



/* Open resident details */

async function openResidentDetails(residentId) {
    const resident = residentManagementRows.find(
        item => item.id === residentId
    );

    if (!resident) return;

    selectedResidentProfile = resident;

    $('residentDetailsTitle').textContent =
        resident.full_name || 'Resident Details';

    const details = [
        ['Full name', resident.full_name],
        ['Mobile number', resident.mobile_number],
        ['District', resident.district_name],
        ['Block', resident.block_name],
        ['Gram Panchayat', resident.gram_panchayat_name],
        ['Village', resident.village_name],
        ['Document type', resident.document_type],
        ['Account status', resident.verification_status],
        ['Submitted', resident.created_at
            ? new Date(resident.created_at).toLocaleString('en-IN')
            : 'Not available'],
        ['Latest review note', resident.verification_note],
        ['Last reviewed', resident.verified_at
            ? new Date(resident.verified_at).toLocaleString('en-IN')
            : 'Not reviewed yet'],
        ['Reviewer ID', resident.verified_by || 'Not reviewed yet']
    ];

    $('residentDetailsContent').innerHTML = `
        <div class="resident-details-grid">
            ${details.map(([label, value]) => `
                <div class="resident-detail-item">
                    <span>${mediaSafeText(label)}</span>
                    <strong>${mediaSafeText(value || 'Not provided')}</strong>
                </div>
            `).join('')}
        </div>

        <section id="residentReviewHistory" class="resident-review-history">
            <h3>Verification Review History</h3>
            <p>Loading review history...</p>
        </section>
    `;

    $('residentReviewNote').value = '';

    // Allow re-review regardless of the current status.
    $('residentReviewControls').classList.remove('hidden');

    updateResidentReviewButtons(resident.verification_status);

    $('residentReviewMessage').textContent = '';

    $('residentDocumentPreview').textContent =
        'Loading document...';

    const modal = $('residentDetailsModal');

    modal.style.display = 'flex';
    modal.setAttribute('aria-hidden', 'false');

    await loadResidentDocument(resident);

    // Load previous decisions and notes.
    await loadResidentReviewHistory(resident.id);
}


/* Secure document preview using private Storage */

async function loadResidentDocument(resident) {
    const preview = $('residentDocumentPreview');

    try {
        const path = resident.document_path;

        if (!path) {
            preview.textContent = 'No verification document was uploaded.';
            return;
        }

        // Ensure the document belongs to this resident.
        if (path.split('/')[0] !== resident.id) {
            throw new Error('Document path does not match the resident.');
        }

        const { data, error } = await db.storage
            .from(RESIDENT_DOCUMENT_BUCKET)
            .createSignedUrl(path, 300);

        if (error) throw error;

        const url = data?.signedUrl;

        if (!url) throw new Error('Could not create a document preview.');

        const extension = path.split('.').pop().toLowerCase();

        let previewHtml = '';

        if (extension === 'pdf') {
            previewHtml = `
                <iframe
                    src="${mediaSafeText(url)}"
                    title="Resident verification document">
                </iframe>
            `;
        } else if (['jpg', 'jpeg', 'png'].includes(extension)) {
            previewHtml = `
                <img
                    src="${mediaSafeText(url)}"
                    alt="Resident verification document">
            `;
        } else {
            previewHtml = '<p>Preview is not available for this file type.</p>';
        }

        preview.innerHTML = previewHtml + `
            <p>
                <a href="${mediaSafeText(url)}"
                    target="_blank"
                    rel="noopener noreferrer">
                    Open document in a new tab
                </a>
            </p>
        `;

    } catch (error) {
        console.error('Document preview error:', error);
        preview.textContent =
            'Could not load document: ' + error.message;
    }
}


/* Close resident details */

function closeResidentDetails() {
    const modal = $('residentDetailsModal');

    modal.style.display = 'none';
    modal.setAttribute('aria-hidden', 'true');

    selectedResidentProfile = null;
}



/* Review or re-review a resident */

async function reviewResidentProfile(decision) {
    const allowedDecisions = [
        'verified',
        'rejected',
        'unverified'
    ];

    if (!allowedDecisions.includes(decision)) {
        return;
    }

    const resident = selectedResidentProfile;

    if (!resident) {
        setResidentManagementMessage(
            'Please select a resident first.',
            'error'
        );
        return;
    }

    const note = $('residentReviewNote').value.trim();

    const buttons = [
        $('verifyResident'),
        $('rejectResident'),
        $('unverifyResident')
    ].filter(Boolean);

    try {
        buttons.forEach(button => button.disabled = true);

        $('residentReviewMessage').textContent =
            'Saving review decision...';

        const { error } = await db.rpc(
            'review_resident_profile',
            {
                p_resident_id: resident.id,
                p_decision: decision,
                p_note: note || null
            }
        );

        if (error) throw error;

        closeResidentDetails();

        await loadResidentManagement(residentManagementProfile);

        setResidentManagementMessage(
            `Resident status successfully changed to ${decision}.`,
            'success'
        );

    } catch (error) {
        console.error('Resident review error:', error);

        $('residentReviewMessage').textContent =
            error.message || 'Unable to save the review decision.';

    } finally {
        buttons.forEach(button => button.disabled = false);
    }
}


function updateResidentReviewButtons(status) {
    const verifyButton = $('verifyResident');
    const rejectButton = $('rejectResident');

    verifyButton.textContent =
        status === 'verified' ? 'Keep Verified' : 'Verify Resident';

    rejectButton.textContent =
        status === 'rejected' ? 'Keep Rejected' : 'Reject Resident';

    // Add a third action for returning a resident to pending.
    let unverifyButton = $('unverifyResident');

    if (!unverifyButton) {
        unverifyButton = document.createElement('button');
        unverifyButton.id = 'unverifyResident';
        unverifyButton.type = 'button';
        unverifyButton.className = rejectButton.className;
        unverifyButton.textContent = 'Set to Unverified';

        $('residentReviewControls').appendChild(unverifyButton);

        unverifyButton.addEventListener('click', () => {
            reviewResidentProfile('unverified');
        });
    }

    unverifyButton.classList.toggle(
        'hidden',
        status === 'unverified'
    );
}



/* Update resident review actions */

function updateResidentReviewButtons(status) {
    const verifyButton = $('verifyResident');
    const rejectButton = $('rejectResident');

    verifyButton.textContent = 'Verify Resident';
    rejectButton.textContent = 'Reject Resident';

    let unverifyButton = $('unverifyResident');

    if (!unverifyButton) {
        unverifyButton = document.createElement('button');
        unverifyButton.id = 'unverifyResident';
        unverifyButton.type = 'button';
        unverifyButton.className = rejectButton.className;
        unverifyButton.textContent = 'Set to Unverified';

        $('residentReviewControls').appendChild(unverifyButton);

        unverifyButton.addEventListener('click', () => {
            reviewResidentProfile('unverified');
        });
    }

    unverifyButton.classList.toggle(
        'hidden',
        status === 'unverified'
    );
}


/* Load resident review history */

async function loadResidentReviewHistory(residentId) {
    const historySection = $('residentReviewHistory');

    if (!historySection) return;

    try {
        const { data, error } = await db
            .from('resident_verification_history')
            .select(`
                id,
                decision,
                review_note,
                reviewed_by,
                reviewed_at
            `)
            .eq('resident_id', residentId)
            .order('reviewed_at', { ascending: false });

        if (error) throw error;

        historySection.innerHTML = `
            <h3>Verification Review History</h3>

            ${(data || []).length
                ? data.map(item => `
                    <article class="resident-history-item">
                        <strong>
                            ${mediaSafeText(item.decision.toUpperCase())}
                        </strong>

                        <p>
                            ${mediaSafeText(
                                item.review_note ||
                                'No additional note provided.'
                            )}
                        </p>

                        <small>
                            Reviewer ID:
                            ${mediaSafeText(item.reviewed_by)}
                        </small>

                        <small>
                            ${mediaSafeText(
                                new Date(item.reviewed_at)
                                    .toLocaleString('en-IN')
                            )}
                        </small>
                    </article>
                `).join('')
                : '<p>No review history available.</p>'
            }
        `;

    } catch (error) {
        console.error('Review history error:', error);

        historySection.innerHTML = `
            <h3>Verification Review History</h3>
            <p>Unable to load review history.</p>
        `;
    }
}


/* Resident Management event listeners */

$('refreshResidents').addEventListener('click', () => {
    if (residentManagementProfile) {
        loadResidentManagement(residentManagementProfile);
    }
});

$('residentSearch').addEventListener('input', renderResidentManagement);

$('residentStatusFilter').addEventListener('change', renderResidentManagement);

$('closeResidentDetails').addEventListener('click', closeResidentDetails);

$('residentDetailsModal').addEventListener('click', event => {
    if (event.target === $('residentDetailsModal')) {
        closeResidentDetails();
    }
});

$('verifyResident').addEventListener('click', () => {
    reviewResidentProfile('verified');
});

$('rejectResident').addEventListener('click', () => {
    reviewResidentProfile('rejected');
});
